﻿var app = angular.module("myApp", []);
app.controller("myCtrl", function ($scope, $http, $timeout) {
    $scope.horarios = ["06:00:00", "06:15:00", "06:30:00",
        "06:45:00", "07:00:00", "07:15:00", "07:30:00", "07:45:00", "08:00:00", "08:15:00", "08:30:00", "08:45:00",
        "09:00:00", "09:15:00", "09:30:00", "09:45:00", "10:00:00", "10:15:00",
        "10:30:00", "10:45:00", "11:00:00", "11:15:00", "11:30:00", "11:45:00",
        "12:00:00", "12:15:00", "12:30:00", "12:45:00", "13:00:00", "13:15:00", "13:30:00", "13:45:00",
        "14:00:00", "14:15:00", "14:30:00", "14:45:00", "15:00:00", "15:15:00", "15:30:00", "15:45:00",
        "16:00:00", "16:15:00", "16:30:00", "16:45:00", "17:00:00", "17:15:00", "17:30:00", "17:45:00", "18:00:00"]
    $scope.estadoForm = "Nuevo";
    $scope.data = {
        endpoints: {
            
          /*  proveedores: "http://localhost:28750/api/Proveedores/",*/
            recibos: "http://localhost:28750/api/tblCitas/"
        },
        proveedores: [],
        horarios: $scope.horarios,
        recibos: []
    };
    $scope.registro = {
        proveedor: {
            id: '',
            nombre: '',
            apellidos: '',
            usuario: ''
        },
        fecha: '',
        hora: '',
        horaFin: ''
    }
    $scope.mensajes = {
        exitoso: '',
        error: '',
        validacion: ''
    }
    //Mensajes de error
    $scope.mostrarError = function (mensaje) {
        $scope.mensajes.error = mensaje;
        $('#modalErrores').modal('open');
        return;
    }

    //Mensajes exitosos
    $scope.exitoso = function (mensaje) {
        $scope.mensajes.exitoso = mensaje;
        $('#modalMensajes').modal('open');
        return;
    }

    //Mensajes de Validacion
    $scope.validacionMensaje = function (mensaje) {
        $scope.mensajes.validacion = mensaje;
        $('#modalValidaciones').modal('open');
        return;
    }

    //Obtener registros
    $scope.getRecibos = function () {
        $http.get($scope.data.endpoints.recibos)
            .then(function (data, status, headers, config) {
                $scope.data.recibos = data.data;
            }, function (data, status, headers, config) {
                //$scope.mostrarError("Error al obtener recibos");
            });
    };

    

    //Retornar el nombre del proveedor
    $scope.getProveedorName = function (id) {
        for (var i = 0; i < $scope.data.proveedores.length; i++) {
            if ($scope.data.proveedores[i].identification == id) {
                return $scope.data.proveedores[i].nombre + ' ' + $scope.data.proveedores[i].apellidos;
            }
        }
    }

    
    //Obtener los proveedores
    $scope.getProveedores = function () {
        $http.get($scope.data.endpoints.proveedores)
            .then(function (data, status, headers, config) {
                $scope.data.proveedores = data.data;
            }, function (data, status, headers, config) {
                //$scope.mostrarError("Error al obtener proveedores");
            });
    };

    
    //Seleccionar Hora Inicio
    $scope.seleccionarHoraInicio = function (hora) {
        for (var i = 0; i < $scope.data.horarios.length; i++) {
            if ($scope.data.horarios[i] == hora) {
                $scope.registro.hora = $scope.data.horarios[i];
                $timeout(function () {
                    $('select').material_select();
                }, 200);
            }
        }
    }

    

    //Seleccionar Proveedor
    $scope.seleccionarProveedorIdentificacion = function (id) {
        for (var i = 0; i < $scope.data.proveedores.length; i++) {
            if ($scope.data.proveedores[i].identification == id) {
                $scope.registro.proveedor.id = $scope.data.proveedores[i].id;
                $scope.registro.proveedor.nombre = $scope.data.proveedores[i].nombre;
                $scope.registro.proveedor.apellidos = $scope.data.proveedores[i].apellidos;
            }
        }
        $('#modal1').modal('close');

        $timeout(function () {
            Materialize.updateTextFields();
        }, 200);
    }

 

    

    //Seleccionar la Hora final de registro
    $scope.seleccionarHoraFinal = function () {
        for (var i = 0; i < $scope.data.horarios.length; i++) {
            if ($scope.data.horarios[i] == $scope.registro.hora) {
                $scope.registro.horaFin = $scope.data.horarios[i + 1];
                $timeout(function () {
                    Materialize.updateTextFields();
                }, 100);
                break;
            }
        }
    }

    //Metodo de Post y Put
    $scope.GuardarRecibo = function () {
        if ($scope.estadoForm == "Nuevo") {
            $scope.crearRecibo();
        } else {
            $scope.editarRecibo();
        }
    }

    //Actualizar Recibo
    $scope.editarRecibo = function () {
        var tblCitas = {
            id: $scope.registro.id,
            idPaciente: $scope.registro.paciente.idPaciente,
            fecha: $scope.registro.fecha + ' 0:00:00.000',
            monto: $scope.registro.monto,
            moneda: $scope.registro.moneda,
            horaInicio: $scope.registro.hora,
            horaFin: $scope.registro.horaFin,
        };

        $http.put(
            $scope.data.endpoints.recibos + $scope.registro.id,
            JSON.stringify(tblCitas)
        ).then(function (data, status, headers, config) {
            $scope.exitoso("Se ha actualizado recibo, consulte el calendario");
            $scope.getRecibos();
            $scope.estadoForm = "Nuevo";
        }, function (data, status, headers, config) {
            /*$scope.mostrarError("Error al guardar recibo");*/
        });
    }

    

    //Actualizar Recibo Eliminar
    $scope.eliminarRecibo = function (id) {
        var dataSend = {
            id: id
        };

        $http.delete(
            $scope.data.endpoints.recibos + id,
            JSON.stringify(dataSend)
        ).then(function (data, status, headers, config) {
            $scope.exitoso("Se ha eliminado recibo");
            $scope.getRecibos();
            $scope.estadoForm = "Nuevo";
        }, function (data, status, headers, config) {
            /*$scope.mostrarError("Error al eliminar recibo");*/
        });
    }


    //GuardarReciboNuevo
    $scope.crearRecibo = function () {
        if ($scope.validarFormulario()) {
            var tblCitas = {
                id: 0,
                idPaciente: $scope.registro.paciente.id,
                fecha: $scope.registro.fecha + ' 0:00:00.000',
                
                horaInicio: $scope.registro.hora,
                horaFin: $scope.registro.horaFin,
                comentario: $scope.registro.registro.comentario,
            }
            $http.post(
                $scope.data.endpoints.recibos,
                JSON.stringify(tblCitas)
            ).then(function (data, status, headers, config) {
                $scope.exitoso("Se ha creado recibo, consulte su recibo");
                $scope.getRecibos();
                $scope.estadoForm = "Nuevo";
            }, function (data, status, headers, config) {
                /*$scope.mostrarError("Error al guardar recibo");*/
            });
        }

    }

    $scope.validarFormulario = function () {
        if ($scope.registro.paciente.id.length == 0) {
            $scope.validacionMensaje("Proveedor Guardado");
            return false;
        }
        
        if ($scope.registro.fecha.length == 0) {
            $scope.validacionMensaje("Debe seleccionar una fecha");
            return false;
        }
        if ($scope.registro.hora.length == 0) {
            $scope.validacionMensaje("Debe seleccionar un hora");
            return false;
        }
        
        return true;
    }

    
    $scope.limpiarFormulario = function () {
        $scope.registro = {
            especialidad: {
                id: '', specialty_type: '', url: ''
            },
           
            proveedor: {
                id: '',
                nombre: '',
                apellidos: ''
            },
            fecha: '',
            hora: '',
            horaFin: ''
        }
        $scope.estadoForm = "Nuevo";
        $timeout(function () {
            $('select').material_select();
        }, 100);
    }


    $timeout(function () {
        $('select').material_select();
    }, 1000);
    $timeout(function () {
        $('select').material_select();
    }, 2000);
    $timeout(function () {
        $('select').material_select();
    }, 3000);
    $timeout(function () {
        $('select').material_select();
    }, 4000);


    //Llamados iniciales
   
    $scope.getProveedores();
    $scope.getRecibos();


    
});