﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace WebAPI.Controllers
{
    public class ProveedoresController : ApiController
    {
        public class Paciente
        {
            public string IDLogin { get; set; }
            public string NombreProveedor { get; set; }
            public string ApellidosProveedor { get; set; }
            public string url { get; set; }
        }
        public class PacientesController : ApiController
        {
            // GET: api/Proveedores
            [ResponseType(typeof(Paciente))]
            public Newtonsoft.Json.Linq.JArray Get()
            {
                WebClient wc = new WebClient();
                var json = wc.DownloadString("http://pruebas2021.database.windows.net/Recibos");
                dynamic dynObj = JsonConvert.DeserializeObject(json);
                return dynObj;
            }

        }
    }
}
